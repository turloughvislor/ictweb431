
function checkPassword() {
    if (document.getElementById('password').value == '42') {
        alert('Correct!');
        window.location.href = "lol.html";
    } else {
        alert('i thought you were better than this smh');
        return false;
    }
}


function disableEnterKeySubmit(event) {
    if (event.keyCode === 13) {
        event.preventDefault();
        return false;
    }
}


document.querySelector('.form1').addEventListener('keypress', disableEnterKeySubmit);